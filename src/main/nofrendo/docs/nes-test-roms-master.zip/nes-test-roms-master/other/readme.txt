up	left  up
down	right down
left	left  down
right	right up
A	
B	
Start	StartGame
Select	

Program	 KZ-S
Graphics misaki
Special
 Thanks  Norix

http://dev.fam.cx/~kz_s/
