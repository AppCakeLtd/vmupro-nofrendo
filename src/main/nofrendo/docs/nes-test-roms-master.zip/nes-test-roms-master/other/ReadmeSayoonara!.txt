SAYOONARA! By Chris C (CMC).
----------

The demo.
---------

This is a small (but lengthy) demo which I programmed for the NES
in October of 2001.  I wrote it because I may be heading off to
work in Japan for a year, and this may be my last opportunity to
release a "major" demo for a while.  So, basically, this demo says
"goodbye" and "thanks" to all those who have made my NES-development
life so fun and rewarding.

There are some scrolltexts inside the demo which explain more.  I suggest
that you read them fully to catch some important tidbits about the demo.

You never know what's in store!!


Compatibility
-------------

Because "Sayoonara!" does a few tricks with the NES' PPU, not all emulators
can run it correctly.  Forget about NESticle.  Get something better if you
have a PC, such as LoopyNES or FCE Ultra.  Even emulators such as BioNES and
FWNES have some problems displaying the demo correctly.  As for other computer
systems, I can't recommend anything at the moment.


Contact
-------

I'm the author of the demo.  My name is Chris Covell.
If you like the demo, feel free to e-mail me at ccovell@direct.ca
Or, look around for my webpage.  It is currently at:
                                       [  http://mypage.direct.ca/c/ccovell ]

The music in the demo was ripped from "Ferrari Grand Prix" on the NES.
Sorry, but I can't compose music.  I'm no good at it.  :-(

So long for now!
